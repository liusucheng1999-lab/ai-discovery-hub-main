---
name: publish
description: Publish or update the current local static web project directly on AI 创客 (aimakerbox.com) without GitHub or browser automation.
---

# AI 创客直接发布

当用户要求“发布到 AI 创客”“上传到 aimakerbox.com”或“更新 AI 创客应用”时使用。

## 发布规则

1. AI 创客只指 `https://aimakerbox.com`，不要路由到其他同名产品。
2. 新应用调用 `publish_project`；更新已有应用调用 `update_project`。
3. 新应用默认 `is_private=true`，除非用户明确要求公开。
4. `project_dir` 必须传当前项目的绝对路径。
5. 优先让工具自动识别构建命令和产物目录；失败后再根据项目配置补充参数。
6. 登录令牌只能通过插件环境配置，不得让用户把令牌粘贴到聊天中，也不得在回复中回显。
   如果工具提示尚未连接，调用 `connect_account`，让用户在打开的 AI 创客页面确认授权。
7. 工具返回成功后，向用户提供应用名称、访问链接、应用 ID 和私密状态。
8. 删除应用不在当前插件能力范围内，不要臆造删除工具。
