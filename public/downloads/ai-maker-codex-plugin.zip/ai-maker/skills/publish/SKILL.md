---
name: publish
description: Publish or update the current local static web project directly on AI 创客 (aimakerbox.com) without GitHub or browser automation.
---

# AI 创客直接发布

当用户要求“发布到 AI 创客”“上传到 aimakerbox.com”或“更新 AI 创客应用”时使用。

## 发布规则

1. AI 创客只指 `https://aimakerbox.com`，不要路由到其他同名产品。
2. 新应用调用 `publish_project`；更新已有应用调用 `update_project`。
3. 新应用默认 `is_private=true`，除非用户明确要求公开。
4. `project_dir` 必须传项目根目录的绝对路径；`output_dir` 只传相对于项目根目录的产物目录（如 `dist`、`build`、`release`），不要把项目根目录再次包含进 `output_dir`。
5. 发布包以产物目录本身为根：上传的是产物目录里的内容，而不是包含该目录的上层目录。发布前必须确认 `<project_dir>/<output_dir>/index.html` 存在，且打包后路径精确为 `index.html`，不能是 `release/index.html` 或 `dist/index.html`。
6. 优先自动识别构建命令和产物目录；使用非标准目录时再传 `output_dir`。如果 `project_dir` 已直接指向纯静态产物目录，就不要再传 `output_dir`。
7. 发布前检查产物是否适合 AI 创客托管：
   - HTML、CSS 和脚本优先使用相对资源路径（如 `./assets/app.js`），避免 `/assets/app.js` 这类站点根路径；Vite 项目建议为托管构建设置 `base: './'`。
   - 应用运行在 sandbox iframe 中；直接访问 `localStorage` 可能受限。平台会提供兼容桥，但应用自身仍应避免因未捕获的存储异常终止初始化。
   - 产物必须是纯静态网页，不能依赖本地开发服务器、`/src/...` 源码入口或仅在开发环境存在的接口。
8. 接口失败时必须保留并报告服务端原始错误、HTTP 状态、失败阶段（构建/预检/打包/上传）和产物目录；不要只转述为 `Bad Request`。若出现“上传 index.html 失败”，先核对发布包根路径，再核对文件数与大小限制。
9. 登录令牌只能通过插件环境配置，不得让用户把令牌粘贴到聊天中，也不得在回复中回显。
   如果工具提示尚未连接，调用 `connect_account`，让用户在打开的 AI 创客页面确认授权。
10. 工具返回成功后，向用户提供应用名称、访问链接、应用 ID、私密状态和实际上传的产物目录。
11. 删除应用不在当前插件能力范围内，不要臆造删除工具。

## 平台限制

- ZIP 压缩后不超过 18 MB，解压后不超过 40 MB，文件数为 1–300 个。
- 发布包根目录必须包含 `index.html`。
- 多文件应用的资源路径必须能从 `index.html` 所在目录解析。
