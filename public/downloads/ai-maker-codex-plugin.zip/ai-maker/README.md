# AI 创客 Codex 插件

将本地 HTML、Vite、React 或 Vue 项目直接发布到 [AI 创客](https://aimakerbox.com)，无需 GitHub 或浏览器模拟上传。

## 包含内容

- `.codex-plugin/plugin.json`：Codex 插件清单
- `.mcp.json`：本地 MCP 服务配置
- `scripts/server.mjs`：构建、打包、授权与上传工具
- `skills/publish/SKILL.md`：Codex 发布规则
- `package.json` / `package-lock.json`：运行依赖

## 安装

1. 解压下载的 `ai-maker-codex-plugin.zip`。
2. 在解压后的插件目录执行 `npm install`。
3. 将该目录作为本地 Codex 插件安装。
4. 新建 Codex 任务并输入：`连接我的 AI 创客账号。`
5. 授权完成后输入：`使用 AI 创客插件，把当前项目构建并发布为私密应用。`

## 隐私

插件包不包含任何用户账号、访问令牌、Cookie 或本机路径。账号连接凭证仅在用户授权后生成，并保存在用户自己的电脑上。
