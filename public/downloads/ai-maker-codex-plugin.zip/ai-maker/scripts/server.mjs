#!/usr/bin/env node
import { execFileSync } from "node:child_process";
import { chmodSync, existsSync, mkdirSync, readFileSync, readdirSync, statSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { basename, join, relative, resolve } from "node:path";
import JSZip from "jszip";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";

const server = new McpServer({ name: "ai-maker", version: "0.1.0" });

function apiBase() {
  return (process.env.AIMAKERBOX_API_URL || "https://aimakerbox.com").replace(/\/$/, "");
}

function accessToken() {
  const token = process.env.AIMAKERBOX_ACCESS_TOKEN || readSavedToken();
  if (!token) {
    throw new Error(
      "AI 创客尚未连接。请在插件设置中配置 AIMAKERBOX_ACCESS_TOKEN，然后重试。不要把令牌写进聊天消息。"
    );
  }
  return token;
}

const credentialsDir = join(homedir(), ".aimakerbox");
const credentialsPath = join(credentialsDir, "credentials.json");

function readSavedToken() {
  if (!existsSync(credentialsPath)) return "";
  try {
    return JSON.parse(readFileSync(credentialsPath, "utf8")).access_token || "";
  } catch {
    return "";
  }
}

function saveToken(token) {
  mkdirSync(credentialsDir, { recursive: true, mode: 0o700 });
  writeFileSync(credentialsPath, JSON.stringify({ access_token: token }, null, 2), { mode: 0o600 });
  chmodSync(credentialsPath, 0o600);
}

function openBrowser(url) {
  const platform = process.platform;
  if (platform === "darwin") execFileSync("open", [url]);
  else if (platform === "win32") execFileSync("cmd", ["/c", "start", "", url]);
  else execFileSync("xdg-open", [url]);
}

function collectFiles(root, current = root, output = []) {
  for (const name of readdirSync(current)) {
    const fullPath = join(current, name);
    const stats = statSync(fullPath);
    if (stats.isDirectory()) collectFiles(root, fullPath, output);
    else output.push({ fullPath, archivePath: relative(root, fullPath) });
  }
  return output;
}

function detectOutputDir(projectDir, requested) {
  if (requested) {
    const explicit = resolve(projectDir, requested);
    if (!existsSync(explicit)) throw new Error(`构建目录不存在：${explicit}`);
    return explicit;
  }
  for (const candidate of ["dist", "build", "out", "public"]) {
    const fullPath = join(projectDir, candidate);
    if (existsSync(join(fullPath, "index.html"))) return fullPath;
  }
  if (existsSync(join(projectDir, "index.html")) && !existsSync(join(projectDir, "package.json"))) {
    return projectDir;
  }
  throw new Error("没有找到包含 index.html 的构建目录，请传入 output_dir。");
}

function buildProject(projectDir, buildCommand) {
  const packagePath = join(projectDir, "package.json");
  if (!existsSync(packagePath)) return;
  const pkg = JSON.parse(readFileSync(packagePath, "utf8"));
  const command = buildCommand || (pkg.scripts?.build ? "npm run build" : "");
  if (!command) return;
  const [program, ...args] = command.split(/\s+/);
  execFileSync(program, args, {
    cwd: projectDir,
    stdio: "inherit",
    env: process.env,
  });
}

async function makeArchive(outputDir) {
  const zip = new JSZip();
  for (const file of collectFiles(outputDir)) {
    zip.file(file.archivePath, readFileSync(file.fullPath));
  }
  if (!zip.file("index.html")) {
    throw new Error("发布包根目录缺少 index.html。");
  }
  return zip.generateAsync({ type: "base64", compression: "DEFLATE", compressionOptions: { level: 6 } });
}

async function request(path, payload) {
  const response = await fetch(`${apiBase()}${path}`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken()}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || `AI 创客返回 ${response.status}`);
  return body;
}

server.tool(
  "connect_account",
  "在浏览器中登录并一键连接当前 AI 创客账号。无需复制访问令牌。",
  {},
  async () => {
    const startResponse = await fetch(`${apiBase()}/api/v1/connector/device`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: "{}",
    });
    const authorization = await startResponse.json();
    if (!startResponse.ok) throw new Error(authorization.error || "无法开始连接");
    openBrowser(authorization.verification_url);

    const deadline = Date.now() + authorization.expires_in * 1000;
    while (Date.now() < deadline) {
      await new Promise((resolvePromise) => setTimeout(resolvePromise, Math.max(2, authorization.interval) * 1000));
      const tokenResponse = await fetch(`${apiBase()}/api/v1/connector/token`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ device_code: authorization.device_code }),
      });
      const tokenResult = await tokenResponse.json();
      if (tokenResponse.status === 202) continue;
      if (!tokenResponse.ok) throw new Error(tokenResult.error || "连接失败");
      saveToken(tokenResult.access_token);
      return {
        content: [{ type: "text", text: "AI 创客账号连接成功。现在可以直接发布当前项目。" }],
      };
    }
    throw new Error("连接请求已过期，请重新连接。");
  }
);

server.tool(
  "publish_project",
  "构建当前本地网页项目并直接上传到 AI 创客。无需 GitHub，默认创建私密应用。",
  {
    project_dir: z.string().describe("项目的绝对路径"),
    name: z.string().min(1).describe("应用名称"),
    description: z.string().default("").describe("应用简介"),
    is_private: z.boolean().default(true).describe("是否为私密应用"),
    build_command: z.string().optional().describe("可选构建命令，例如 npm run build"),
    output_dir: z.string().optional().describe("相对项目目录的构建产物目录，例如 dist")
  },
  async (args) => {
    const projectDir = resolve(args.project_dir);
    buildProject(projectDir, args.build_command);
    const outputDir = detectOutputDir(projectDir, args.output_dir);
    const archive_base64 = await makeArchive(outputDir);
    const result = await request("/api/v1/apps", {
      name: args.name,
      description: args.description,
      is_private: args.is_private,
      filename: `${basename(projectDir)}.zip`,
      archive_base64,
    });
    return { content: [{ type: "text", text: JSON.stringify(result, null, 2) }] };
  }
);

server.tool(
  "update_project",
  "重新构建当前项目并覆盖 AI 创客上的已有应用，保持原访问链接。",
  {
    app_id: z.string().min(1).describe("AI 创客应用 ID"),
    project_dir: z.string().describe("项目的绝对路径"),
    build_command: z.string().optional(),
    output_dir: z.string().optional()
  },
  async (args) => {
    const projectDir = resolve(args.project_dir);
    buildProject(projectDir, args.build_command);
    const outputDir = detectOutputDir(projectDir, args.output_dir);
    const archive_base64 = await makeArchive(outputDir);
    const result = await request(`/api/v1/apps/${encodeURIComponent(args.app_id)}/deploy`, {
      filename: `${basename(projectDir)}.zip`,
      archive_base64,
    });
    return { content: [{ type: "text", text: JSON.stringify(result, null, 2) }] };
  }
);

await server.connect(new StdioServerTransport());
